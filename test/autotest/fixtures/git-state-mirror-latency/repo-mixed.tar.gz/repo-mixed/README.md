# repo-mixed

Fixture for the mixed (blue) bucket: additions and modifications coexist.
